$(function () {

    CanvasJS.addColorSet("customColorSet", [
        "#393f63",
        "#e5d8B0",
        "#ffb367",
        "#f98461",
        "#d9695f",
        "#bd203e",
    ]);

    // ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ Zingchart to gauge AQHI:
    var AQHIChart;
    window.feed = function (callback) {
        var tick = {};
        tick.plot0 = Math.floor(Math.random() * (1 - 10 + 1) + 10)
        callback(JSON.stringify(tick));
    };
    window.createAQHIChart = function() {

        var AQHIChart = {
            type: "gauge",
            "title": {
                "text": "Live AQHI Value",
                offsetY: 330
            },
            globals: {
                fontSize: 15
            },
            plotarea: {
                marginTop: 80
            },
            plot: {
                size: '100%',
                valueBox: {
                    placement: 'center',
                    text: '%v', //default
                    fontSize: 15,
                    fontFamily: "Roboto",
                    fontWeight: 300,
                    rules: [
                        {
                            rule: '%v >= 10',
                            text: '<br><br><br>%v<br>Very High Risk'
                        },
                        {
                            rule: '%v < 10 && %v >= 7',
                            text: '\<br><br><br>%v<br>High Risk'
                        },
                        {
                            rule: '%v < 7 && %v >= 4',
                            text: '\<br><br><br>%v<br>Moderate Risk'
                        },
                        {
                            rule: '%v < 4 && %v >= 1',
                            text: '\<br><br><br>%v<br>Low Risk'
                        }
                    ]
                }
            },
            tooltip: {
                borderRadius: 5
            },
            scaleR: {
                aperture: 180,
                minValue: 1,
                maxValue: 10,
                step: 1,
                center: {
                    visible: false
                },
                tick: {
                    visible: false
                },
                item: {
                    offsetR: 0,
                    rules: [
                        {
                            rule: '%i == 9',
                            offsetX: 15
                        }
                    ]
                },
                labels: ['1', '2', '3', '4', '5', '6', '7', '8', '9', '10'],
                ring: {
                    size: 30,
                    rules: [{
                        rule: '1 <= %v && %v < 3',
                        backgroundColor: '#393F63'
                    },
                        {
                            rule: '3 <= %v && %v < 6',
                            backgroundColor: '#E5D8B0'
                        },
                        {
                            rule: '6 <= %v && %v < 9',
                            backgroundColor: '#F98461'
                        },
                        {
                            rule: '%v >= 9',
                            backgroundColor: '#bd203e'
                        }
                    ]
                }
            },
            refresh: {
                type: "feed",
                transport: "js",
                url: "feed()",
                interval: 3000,
                resetTimeout: 1000
            },
            series: [
                {
                    values: [1], // starting value
                    backgroundColor: 'black',
                    indicator: [5, 2, 2, 2, 1.5],
                    animation: {
                        effect: 2,
                        method: 450,
                        sequence: 4,
                        speed: 2000
                    },
                }
            ]
        };

        zingchart.render({
            id: 'AQHIChart',
            data: AQHIChart,
            height: 300,
            width: "100%"
        });

    }

    window.removeAQHIChart = function () {

        zingchart.exec("AQHIChart", "destroy");

    }

    // ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ Zingchart to gauge AQI
    var AQIChart;
    window.feed2 = function (callback) {
        var tick2 = {};
        tick2.plot0 = Math.floor(Math.random() * (5 - 370 + 1) + 370)
        callback(JSON.stringify(tick2));
    };
    window.createAQIChart = function() {

        AQIChart = {
            type: "gauge",
            "title": {
                "text": "Live AQHI Value",
                offsetY: 330
            },
            globals: {
                fontSize: 15
            },
            plotarea: {
                marginTop: 80
            },
            plot: {
                size: '100%',
                valueBox: {
                    placement: 'center',
                    text: '%v', //default
                    fontSize: 15,
                    fontFamily: "Roboto",
                    fontWeight: 300,
                    rules: [{
                        rule: '%v >= 300',
                        text: '<br><br><br>%v<br>Hazardous'
                    },
                        {
                            rule: '%v < 300 && %v >= 200',
                            text: '\<br><br><br>%v<br>Very Unhealthy'
                        },
                        {
                            rule: '%v < 200 && %v >= 150',
                            text: '\<br><br><br>%v<br>Unhealthy'
                        },
                        {
                            rule: '%v < 150 && %v >= 100',
                            text: '\<br><br><br>%v<br>Unhealthy for Sensitive Groups'
                        },
                        {
                            rule: '%v < 100 && %v > 50',
                            text: '\<br><br><br>%v<br>Moderate'
                        },
                        {
                            rule: '%v <=  50',
                            text: '\<br><br><br>%v<br>Good'
                        }
                    ]
                }
            },
            tooltip: {
                borderRadius: 5
            },
            scaleR: {
                aperture: 180,
                minValue: 0,
                maxValue: 400,
                step: 50,
                center: {
                    visible: false
                },
                tick: {
                    visible: false
                },
                item: {
                    offsetR: 0,
                    rules: [
                        {
                            rule: '%i == 9',
                            offsetX: 15
                        }
                    ]
                },
                labels: ['0', '50', '100', '150', '200', '250', '300', '350', '400'],
                ring: {
                    size: 30,
                    rules: [{
                        rule: '%v <= 25',
                        backgroundColor: '#393F63'
                    },
                        {
                            rule: '%v > 25 && %v <= 50',
                            backgroundColor: '#E5D8B0'
                        },
                        {
                            rule: '%v > 75 && %v <= 100',
                            backgroundColor: '#ffb367'
                        },
                        {
                            rule: '%v > 125 && %v <= 175',
                            backgroundColor: '#f98461'
                        },
                        {
                            rule: '%v > 175 && %v <= 250',
                            backgroundColor: '#d9695f'
                        },
                        {
                            rule: '%v >= 300',
                            backgroundColor: 'rgba(189,32,62,0.78)'
                        }
                    ]
                }
            },
            refresh: {
                type: "feed",
                transport: "js",
                url: "feed2()",
                interval: 3000,
                resetTimeout: 1000
            },
            series: [
                {
                    values: [1], // starting value
                    backgroundColor: 'black',
                    indicator: [5, 2, 2, 2, 1.5],
                    animation: {
                        effect: 2,
                        method: 450,
                        sequence: 4,
                        speed: 2000
                    },
                }
            ]
        };

        zingchart.render({
            id: 'AQIChart',
            data: AQIChart,
            height: 300,
            width: "100%"
        });

    }

    window.removeAQIChart = function () {

        zingchart.exec("AQIChart", "destroy");

    }

    // ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ CanvasJS chart to show Relative Humidity
    var humidityDataPoints = [];
    var relHumOptions = {
        animationDuration: 800,
        animationEnabled: true,
        backgroundColor: "white",
        axisX: {
            labelFontColor: "#717171",
            labelFontSize: 18,
            fontFamily: "Roboto",
            fontWeight: 300,
            lineThickness: 0,
            tickThickness: 0,
            interval: 4,
            intervalType: "second",
            lineColor: "#a2a2a2",
            tickColor: "transparent",
            tickLength: 2,
        },
        axisY: {
            title: "Relative Humidity (%)",
            gridThickness: 0,
            fontFamily: "Roboto",
            fontWeight: 300,
            labelFontColor: "#717171",
            lineColor: "#a2a2a2",
            tickColor: "#a2a2a2"
        },
        toolTip: {
            shared: true,
        },
        data: [{
            indexLabelFontColor: "#717171",
            indexLabelFontFamily: "Roboto",
            indexLabelFontSize: 18,
            indexLabelPlacement: "outside",
            type: "spline",
            xValueType: "dateTime",
            name: "Measured Relative Humidity",
            showInLegend: true,
            legendMarkerType: "none",
            legendMarkerColor: "#fffff",
            xValueFormatString: "hh:mm:ss TT",
            dataPoints: humidityDataPoints,
            yValueFormatString: "## ppm"

        }]
    }
    var relativeHumidityChart;
    var relHumInterval;

    window.createRelHumChart = function () {

        relativeHumidityChart = new CanvasJS.Chart("relative-humidity-chart", relHumOptions);
        updateRelativeHumidityChart(humidityDataPoints.length);
        relHumInterval = setInterval(function() {updateRelativeHumidityChart()}, 2500);

    }

    window.removeRelHumChart = function () {

        humidityDataPoints.length = 0;
        clearInterval(relHumInterval);
        relativeHumidityChart.destroy();

    }

    // ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ CanvasJS chart to show CO Concentration
    var coDataPoints = []; // dataPoints
    var coOptions = {
        animationDuration: 800,
        animationEnabled: true,
        backgroundColor: "white",
        colorSet: "customColorSet",
        axisX: {
            labelFontColor: "#717171",
            labelFontSize: 18,
            fontFamily: "Roboto",
            fontWeight: 300,
            lineThickness: 0,
            tickThickness: 0,
            interval: 2,
            intervalType: "second",
            lineColor: "#a2a2a2",
            tickColor: "transparent",
            tickLength: 2,
        },
        axisY: {
            title: "Carbon Monoxide Concentration (ppm)",
            gridThickness: 0,
            fontFamily: "Roboto",
            fontWeight: 300,
            labelFontColor: "#717171",
            lineColor: "#a2a2a2",
            tickColor: "#a2a2a2"
        },
        toolTip: {
            shared: true
        },
        data: [
            {
                indexLabelFontColor: "#717171",
                indexLabelFontFamily: "Roboto",
                indexLabelFontSize: 18,
                indexLabelPlacement: "outside",
                type: "spline",
                xValueType: "dateTime",
                name: "Measured Carbon Monoxide Value",
                showInLegend: true,
                legendMarkerType: "none",
                legendMarkerColor: "#fffff",
                xValueFormatString: "hh:mm:ss TT",
                dataPoints: coDataPoints,
                yValueFormatString: "## ppm"
            }]
    };
    var live_co_chart;
    var coInterval;

    window.createCOChart = function () {

        live_co_chart = new CanvasJS.Chart("live-co-chart", coOptions);
        updateCOChart(coDataPoints.length);
        coInterval = setInterval(function() {updateCOChart()}, 2500);

    }

    window.removeCOChart = function () {

        coDataPoints.length = 0;
        clearInterval(coInterval);
        live_co_chart.destroy();

    }

    // ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ CanvasJS chart to show NO2

    var no2DataPoints = []; // dataPoints
    var no2Options = {
        animationDuration: 800,
        animationEnabled: true,
        backgroundColor: "white",
        colorSet: "customColorSet",
        zoomEnabled: true,
        axisX: {
            labelFontColor: "#717171",
            labelFontSize: 18,
            fontFamily: "Roboto",
            fontWeight: 300,
            lineThickness: 0,
            tickThickness: 0,
            interval: 2,
            intervalType: "second",
            lineColor: "#a2a2a2",
            tickColor: "transparent",
            tickLength: 2,
        },
        axisY: {
            title: "Nitrogen Dioxide (Concentration, ppb)",
            suffix: " ppb",
            gridThickness: 0,
            fontFamily: "Roboto",
            fontWeight: 300,
            labelFontColor: "#717171",
            lineColor: "#a2a2a2",
            tickColor: "#a2a2a2"
        },
        toolTip: {
            shared: true
        },
        legend:{
            cursor: "pointer",
            verticalAlign: "bottom",
            fontFamily: "Roboto",
            fontWeight: 300,
            fontColor: "dimGrey"
        },
        data: [{
            indexLabelFontColor: "#717171",
            indexLabelFontFamily: "Roboto",
            indexLabelFontSize: 18,
            indexLabelPlacement: "outside",
            type: "spline",
            xValueType: "dateTime",
            name: "Measured Nitrogen Dioxide Value",
            showInLegend: true,
            legendMarkerType: "none",
            legendMarkerColor: "#fffff",
            xValueFormatString: "hh:mm:ss TT",
            dataPoints: no2DataPoints,
            yValueFormatString: "## ppB"

        }]};
    var live_no2_chart;
    var no2Interval;

    window.createNO2Chart = function () {

        live_no2_chart = new CanvasJS.Chart("live-no2-chart", no2Options);
        updateNO2Chart(no2DataPoints.length);
        no2Interval = setInterval(function() {updateNO2Chart()}, 2500);

    }

    window.removeNO2Chart = function () {

        no2DataPoints.length = 0;
        clearInterval(no2Interval);
        live_no2_chart.destroy();

    }

    // ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ CanvasJS chart to show Ozone

    var ozoneDataPoints = []; // dataPoints
    var ozoneOptions = {
        animationDuration: 800,
        animationEnabled: true,
        backgroundColor: "white",
        colorSet: "customColorSet",
        zoomEnabled: true,
        axisX: {
            labelFontColor: "#717171",
            labelFontSize: 18,
            fontFamily: "Roboto",
            fontWeight: 300,
            lineThickness: 0,
            tickThickness: 0,
            interval: 2,
            intervalType: "second",
            lineColor: "#a2a2a2",
            tickColor: "transparent",
            tickLength: 2,
        },
        axisY: {
            title: "Ozone (Concentration, ppb)",
            suffix: " ppb",
            gridThickness: 0,
            fontFamily: "Roboto",
            fontWeight: 300,
            labelFontColor: "#717171",
            lineColor: "#a2a2a2",
            tickColor: "#a2a2a2"
        },
        toolTip: {
            shared: true
        },
        legend:{
            cursor: "pointer",
            verticalAlign: "bottom",
            fontFamily: "Roboto",
            fontWeight: 300,
            fontColor: "dimGrey"
        },
        data: [{
            indexLabelFontColor: "#717171",
            indexLabelFontFamily: "Roboto",
            indexLabelFontSize: 18,
            indexLabelPlacement: "outside",
            type: "spline",
            xValueType: "dateTime",
            name: "Measured Ozone Value",
            showInLegend: true,
            legendMarkerType: "none",
            legendMarkerColor: "#fffff",
            xValueFormatString: "hh:mm:ss TT",
            dataPoints: ozoneDataPoints,
            yValueFormatString: "## ppB"

        }]};
    var live_ozone_chart;
    var ozoneInterval;

    window.createOzoneChart = function () {

        live_ozone_chart = new CanvasJS.Chart("live-ozone-chart", ozoneOptions);
        updateOzoneChart(ozoneDataPoints.length);
        ozoneInterval = setInterval(function() {updateOzoneChart()}, 2500);

    }

    window.removeOzoneChart = function () {

        ozoneDataPoints.length = 0;
        clearInterval(ozoneInterval);
        live_ozone_chart.destroy();

    }

    // ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ CanvasJS chart to show Pressure

    var presDataPoints = []; // dataPoints
    var presOptions = {
        animationDuration: 800,
        animationEnabled: true,
        backgroundColor: "white",
        colorSet: "customColorSet",
        zoomEnabled: true,
        axisX: {
            labelFontColor: "#717171",
            labelFontSize: 18,
            fontFamily: "Roboto",
            fontWeight: 300,
            lineThickness: 0,
            tickThickness: 0,
            interval: 2,
            intervalType: "second",
            lineColor: "#a2a2a2",
            tickColor: "transparent",
            tickLength: 2,
        },
        axisY: {
            title: "Pressure (kPa)",
            suffix: " kPa",
            gridThickness: 0,
            fontFamily: "Roboto",
            fontWeight: 300,
            labelFontColor: "#717171",
            lineColor: "#a2a2a2",
            tickColor: "#a2a2a2"
        },
        toolTip: {
            shared: true
        },
        legend:{
            cursor: "pointer",
            verticalAlign: "bottom",
            fontFamily: "Roboto",
            fontWeight: 300,
            fontColor: "dimGrey"
        },
        data: [{
            indexLabelFontColor: "#717171",
            indexLabelFontFamily: "Roboto",
            indexLabelFontSize: 18,
            indexLabelPlacement: "outside",
            type: "spline",
            xValueType: "dateTime",
            name: "Measured Pressure",
            showInLegend: true,
            legendMarkerType: "none",
            legendMarkerColor: "#fffff",
            xValueFormatString: "hh:mm:ss TT",
            dataPoints: presDataPoints,
            yValueFormatString: "## kPa"

        }]};
    var live_pres_chart;
    var presInterval;

    window.createPresChart = function () {

        live_pres_chart = new CanvasJS.Chart("live-pressure-chart", presOptions);
        updatePresChart(presDataPoints.length);
        presInterval = setInterval(function() {updatePresChart()}, 2500);

    }

    window.removePresChart = function () {

        presDataPoints.length = 0;
        clearInterval(presInterval);
        live_pres_chart.destroy();

    }

    // ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ CanvasJS chart to show Temperature

    var tempDataPoints = [];
    var tempOptions = {
        animationDuration: 800,
        animationEnabled: true,
        backgroundColor: "white",
        colorSet: "customColorSet",
        zoomEnabled: true,
        axisX: {
            labelFontColor: "#717171",
            labelFontSize: 18,
            fontFamily: "Roboto",
            fontWeight: 300,
            lineThickness: 0,
            tickThickness: 0,
            interval: 2,
            intervalType: "second",
            lineColor: "#a2a2a2",
            tickColor: "transparent",
            tickLength: 2,
        },
        axisY: {
            title: "Temperature (°C)",
            suffix: " °C",
            gridThickness: 0,
            fontFamily: "Roboto",
            fontWeight: 300,
            labelFontColor: "#717171",
            lineColor: "#a2a2a2",
            tickColor: "#a2a2a2"
        },
        toolTip: {
            shared: true
        },
        legend:{
            cursor: "pointer",
            verticalAlign: "bottom",
            fontFamily: "Roboto",
            fontWeight: 300,
            fontColor: "dimGrey"
        },
        data: [{
            indexLabelFontColor: "#717171",
            indexLabelFontFamily: "Roboto",
            indexLabelFontSize: 18,
            indexLabelPlacement: "outside",
            type: "spline",
            xValueType: "dateTime",
            name: "Measured Temperature",
            showInLegend: true,
            legendMarkerType: "none",
            legendMarkerColor: "#fffff",
            xValueFormatString: "hh:mm:ss TT",
            dataPoints: tempDataPoints,
            yValueFormatString: "##°C"

        }]};
    var live_temp_chart;
    var timeInterval;

    window.createTempChart = function () {

        live_temp_chart = new CanvasJS.Chart("live-temperature-chart", tempOptions);
        updateTempChart(tempDataPoints.length);
        timeInterval = setInterval(function() {updateTempChart()}, 2500);

    }

    window.removeTempChart = function () {

        tempDataPoints.length = 0;
        clearInterval(timeInterval);
        live_temp_chart.destroy();

    }

    // ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ CanvasJS chart to show Particulate
    var part2p5DataPoints = []; // dataPoints
    var part10DataPoints = []; // dataPoints
    function toggleDataSeries7(e) {
        var index = legendItem.datasetIndex;
        var ci = this.chart;
        var alreadyHidden = (ci.getDatasetMeta(index).hidden === null) ? false : ci.getDatasetMeta(index).hidden;

        ci.data.datasets.forEach(function(e, i) {
            var meta = ci.getDatasetMeta(i);

            if (i !== index) {
                if (!alreadyHidden) {
                    meta.hidden = meta.hidden === null ? !meta.hidden : null;
                } else if (meta.hidden === null) {
                    meta.hidden = true;
                }
            } else if (i === index) {
                meta.hidden = null;
            }
        });

        ci.update();
    }
    var partOptions = {
        animationDuration: 800,
        animationEnabled: true,
        backgroundColor: "white",
        colorSet: "customColorSet",
        axisX: {
            labelFontColor: "#717171",
            labelFontSize: 18,
            fontFamily: "Roboto",
            fontWeight: 300,
            lineThickness: 0,
            tickThickness: 0,
            interval: 4,
            intervalType: "second",
            lineColor: "#a2a2a2",
            tickColor: "transparent",
            tickLength: 4,
        },
        axisY: {
            title: "Particulate (µg/m³)",
            suffix: " µg/m³",
            gridThickness: 0,
            fontFamily: "Roboto",
            fontWeight: 300,
            labelFontColor: "#717171",
            lineColor: "#a2a2a2",
            tickColor: "#a2a2a2"
        },
        toolTip: {
            shared: true
        },
        legend:{
            cursor: "pointer",
            verticalAlign: "bottom",
            fontFamily: "Roboto",
            fontWeight: 300,
            fontColor: "dimGrey",
            itemClick: toggleDataSeries7
        },
        data: [{
            indexLabelFontColor: "#717171",
            indexLabelFontFamily: "Roboto",
            indexLabelFontSize: 18,
            indexLabelPlacement: "outside",
            type: "spline",
            xValueType: "dateTime",
            name: "Measured Particulate Value 2.5 ",
            showInLegend: true,
            legendMarkerType: "none",
            legendMarkerColor: "#fffff",
            xValueFormatString: "hh:mm:ss TT",
            dataPoints: part2p5DataPoints,
            yValueFormatString: "## µg/m³"
        },
            {
                indexLabelFontColor: "#717171",
                indexLabelFontFamily: "Roboto",
                indexLabelFontSize: 18,
                indexLabelPlacement: "outside",
                type: "spline",
                xValueType: "dateTime",
                name: "Measured Particulate Value 10 ",
                showInLegend: true,
                legendMarkerType: "none",
                legendMarkerColor: "#fffff",
                xValueFormatString: "hh:mm:ss TT",
                dataPoints: part10DataPoints,
                yValueFormatString: "## µg/m³"
            }
        ]
    }
    var part_chart;
    var partInterval;

    window.createPartChart = function () {

        part_chart = new CanvasJS.Chart("live-particulate-chart", partOptions);
        updatePartChart(part10DataPoints.length);
        partInterval = setInterval(function() {updatePartChart()}, 2500);

    }

    window.removePartChart = function () {

        part2p5DataPoints.length = part10DataPoints.length = 0;
        clearInterval(partInterval);
        part_chart.destroy();

    }

    //------------------------------- UPDATE METHODS ------------------------------------//

    var coXVal = 0;
    var coYVal = 900;
    var coUpdateInterval = 800;
    var coDataLength = 20; // number of dataPoints visible at any point
    var coTime = new Date();

    function updateCOChart(dataIndex) {

        dataIndex = dataIndex || 1;

        for (var j = 0; j < dataIndex; j+=2) {
            coTime.setTime(coTime.getTime() + coUpdateInterval)
            coYVal = Math.floor(Math.random() * (1 - 20 + 1) + 20)
            coDataPoints.push({
                x: coTime.getTime(),
                y: coYVal
            });
            coXVal++;
        }

        while (coDataPoints.length > coDataLength) {
            coDataPoints.shift();
        }
        live_co_chart.options.data[0].legendText = "Current Carbon Monoxide Value: " + coYVal + " ppb"

        live_co_chart.render();

    }

    var no2XVal = 0;
    var no2YVal = 900;
    var no2UpdateInterval = 800;
    var no2DataLength = 20; // number of dataPoints visible at any point
    var no2Time = new Date();

    function updateNO2Chart(dataIndex) {

        dataIndex = dataIndex || 1;

        for (var j = 0; j < dataIndex; j+=2) {
            no2Time.setTime(no2Time.getTime() + no2UpdateInterval)
            no2YVal = Math.floor(Math.random() * (1 - 20 + 1) + 20)
            no2DataPoints.push({
                x: no2Time.getTime(),
                y: no2YVal
            });
            no2XVal++;
        }

        while (no2DataPoints.length > no2DataLength) {
            no2DataPoints.shift();
        }
        live_no2_chart.options.data[0].legendText = "Current Nitrogen Dioxide Value: " + no2YVal + " ppb";

        live_no2_chart.render();

    }

    var ozoneXVal = 0;
    var ozoneYVal = 900;
    var ozoneUpdateInterval = 800;
    var ozoneDataLength = 20; // number of dataPoints visible at any point
    var ozoneTime = new Date();

    function updateOzoneChart(dataIndex) {

        dataIndex = dataIndex || 1;

        for (var j = 0; j < dataIndex; j+=2) {
            ozoneTime.setTime(ozoneTime.getTime() + ozoneUpdateInterval)
            ozoneYVal = Math.floor(Math.random() * (1 - 20 + 1) + 20)
            ozoneDataPoints.push({
                x: ozoneTime.getTime(),
                y: ozoneYVal
            });
            ozoneXVal++;
        }

        while (ozoneDataPoints.length > ozoneDataLength) {
            ozoneDataPoints.shift();
        }
        live_ozone_chart.options.data[0].legendText = "Current Ozone Concentration Value: " + ozoneYVal + " ppb";

        live_ozone_chart.render();

    }

    var presXVal = 0;
    var presYVal = 900;
    var presUpdateInterval = 800;
    var presDataLength = 20; // number of dataPoints visible at any point
    var presTime = new Date();

    function updatePresChart(dataIndex) {

        dataIndex = dataIndex || 1;

        for (var j = 0; j < dataIndex; j+=2) {
            presTime.setTime(presTime.getTime() + presUpdateInterval)
            presYVal = Math.floor(Math.random() * (1 - 20 + 1) + 20)
            presDataPoints.push({
                x: presTime.getTime(),
                y: presYVal
            });
            presXVal++;
        }

        while (presDataPoints.length > presDataLength) {
            presDataPoints.shift();
        }
        live_pres_chart.options.data[0].legendText = "Current Pressure Value: " + presYVal + " ppb";

        live_pres_chart.render();

    }

    var tempXVal = 0;
    var tempYVal = 900;
    var tempUpdateInterval = 800;
    var tempDataLength = 20; // number of dataPoints visible at any point
    var tempTime = new Date();

    function updateTempChart(count6) {

        count6 = count6 || 1;

        for (var j = 0; j < count6; j++) {
            tempTime.setTime(tempTime.getTime() + tempUpdateInterval)
            tempYVal = Math.floor(Math.random() * (28 - 11 + 1) + 11)
            tempDataPoints.push({
                x: tempTime.getTime(),
                y: tempYVal
            });

        }

        if (tempDataPoints.length > tempDataLength) {
            tempDataPoints.shift();
        }
        live_temp_chart.options.data[0].legendText = "Current Temperature: " + tempYVal + " °C"
        live_temp_chart.render();

    }

    // update "Relative Humidity" chart every 2.5 seconds
    var relHumYVal = 0;
    var relHumUpdateInterval = 2500;
    var relHumDataLength = 20; // number of dataPoints visible at any point

    var relHumTime = new Date();

    function updateRelativeHumidityChart(dataIndex) {

        dataIndex = dataIndex || 1;

        for (var j = 0; j < dataIndex; j+=2) {
            relHumTime.setTime(relHumTime.getTime() + relHumUpdateInterval)
            relHumYVal = Math.floor(Math.random() * (30 - 80 + 1) + 80)
            humidityDataPoints.push({
                x: relHumTime.getTime(),
                y: relHumYVal
            });
        }

        while (humidityDataPoints.length > relHumDataLength) {

            humidityDataPoints.shift();
        }
        relativeHumidityChart.options.data[0].legendText = "Current Humidity: " + relHumYVal + " %"
        relativeHumidityChart.render();
    }

    var p25xVal = 0;
    var p25yVal = 900;
    var p10yVal = 900;
    var partUpdateInterval = 2500;
    var partDataLength = 20; // number of dataPoints visible at any point
    var partTime = new Date();
    var updatePartChart = function (count7) {
        count7 = count7 || 1;
        var deltaY1, deltaY2;
        for (var j = 0; j < count7; j+=2) {
            partTime.setTime(partTime.getTime() + partUpdateInterval)
            p25yVal = Math.floor(Math.random() * (28 - 11 + 1) + 11)
            p10yVal = Math.floor(Math.random() * (28 - 11 + 1) + 11)
            part2p5DataPoints.push({
                x: partTime.getTime(),
                y: p25yVal
            });
            part10DataPoints.push({
                x: partTime.getTime(),
                y : p10yVal
            })
            p25xVal++;
        }
        if (part2p5DataPoints.length > partDataLength || part10DataPoints.length > partDataLength) {
            part2p5DataPoints.shift();
            part10DataPoints.shift();
        }
        part_chart.options.data[0].legendText = "Current Particulate Value (2.5): " + p25yVal + " µg/m³"
        part_chart.options.data[1].legendText = "Current Particulate Value (10): " + p10yVal + " µg/m³"
        part_chart.render();
    };

    // chart properties customized further based on screen width
    function chartPropertiesCustomization(chart) {
        if ($(window).outerWidth() >= 1920) {

            chart.options.legend.fontSize = 14;
            chart.options.legend.horizontalAlign = "left";
            chart.options.legend.verticalAlign = "center";
            chart.options.legend.maxWidth = null;

        } else if ($(window).outerWidth() < 1920 && $(window).outerWidth() >= 1200) {

            chart.options.legend.fontSize = 14;
            chart.options.legend.horizontalAlign = "left";
            chart.options.legend.verticalAlign = "center";
            chart.options.legend.maxWidth = 140;

        } else if ($(window).outerWidth() < 1200 && $(window).outerWidth() >= 992) {

            chart.options.legend.fontSize = 12;
            chart.options.legend.horizontalAlign = "center";
            chart.options.legend.verticalAlign = "top";
            chart.options.legend.maxWidth = null;

        } else if ($(window).outerWidth() < 992) {

            chart.options.legend.fontSize = 14;
            chart.options.legend.horizontalAlign = "center";
            chart.options.legend.verticalAlign = "bottom";
            chart.options.legend.maxWidth = null;

        }

        chart.render();
    }

    function sidebarToggleOnClick() {
        $('#sidebar-toggle-button').on('click', function () {
            $('#sidebar').toggleClass('sidebar-toggle');
            $('#page-content-wrapper').toggleClass('page-content-toggle');
        });
    }

    (function init() {
        sidebarToggleOnClick();
    })();

})
;