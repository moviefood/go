'use strict'
var currentNumber = 0;
const {Client} = require('@elastic/elasticsearch')
const client = new Client({node: 'http://search-unbcelastic-ubuj4dvcgwxoyf7fmwgexwgyxa.us-east-2.es.amazonaws.com'})

async function run() {

    var searchBody = {
        index: 'wirl',
        body: {
            "size": 1,
            "sort": [
                {
                    "datetime": {
                        "order": "desc"
                    }
                }
            ]
        }
    };

    async function searchAndDisplay() {

        // Let's search!
        const {body} = await client.search(searchBody);

        if (body.hits.total !== currentNumber) {
            console.log(body.hits.total);
            console.log(body.hits.hits);
            currentNumber = body.hits.total;
        }

    }

    searchAndDisplay();
    setInterval(searchAndDisplay, 3000);
}

run().catch(console.log);